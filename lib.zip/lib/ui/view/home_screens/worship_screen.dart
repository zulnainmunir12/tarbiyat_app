import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class WorshipScreenView extends StatefulWidget{
  _WorshipScreenViewState createState()=> _WorshipScreenViewState();
}
class _WorshipScreenViewState extends State<WorshipScreenView>{
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }

}