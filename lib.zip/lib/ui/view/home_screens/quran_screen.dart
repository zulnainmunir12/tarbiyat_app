import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class QuranScreenView extends StatefulWidget{
  _QuranScreenViewState createState()=> _QuranScreenViewState();
}
class _QuranScreenViewState extends State<QuranScreenView>{
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }

}