import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HadithScreenView extends StatefulWidget{
  _HadithScreenViewState createState()=> _HadithScreenViewState();
}
class  _HadithScreenViewState extends State<HadithScreenView>{
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }

}