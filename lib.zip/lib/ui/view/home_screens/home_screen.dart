import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomeScreenView extends StatefulWidget {
  _HomeScreenViewState createState() => _HomeScreenViewState();
}

class _HomeScreenViewState extends State<HomeScreenView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
